These icons can be used in personal as well as commercial projects.
If used in any project , credit to the author will be appreciated.

thanks for downloading...

http://kyo-tux.deviantart.com/