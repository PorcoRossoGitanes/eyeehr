Included in this package is a checkout of XSLTForms version 562, from 2012-11-28.

You can retrieve the same files with

	svn checkout https://xsltforms.svn.sourceforge.net/svnroot/xsltforms/trunk/build/
	
The files build.xml, expath-pkg.xml, and repo.xml are part of the eXist-db package system and do not belong to XSLTForms.

For more information on XSLTForms, consult <http://www.agencexml.com/xsltforms>.

An eXist-db app, XLSTForms-Demo, containing examples of XSLTForms running with eXist-db, is available.