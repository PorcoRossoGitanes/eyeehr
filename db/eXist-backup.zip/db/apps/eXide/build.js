{
	appDir: "./js",
	baseUrl: "."
	name: "main.js",
	out: "./xqlint.js",
	//dir: "build/xqlint",
	paths: {
		"xqlint": "support/xqlint/lib"
	}
}